# Generare l'APK nel cloud (senza PC locale)

Questo progetto include `.github/workflows/android-apk.yml`: GitHub Actions usa un ambiente cloud con Godot 4.3 per importare il progetto, eseguire il controllo statico ed esportare un APK Android debug.

## Procedura
1. Crea un repository GitHub nuovo e privato.
2. Carica il contenuto di questa cartella nel repository, mantenendo la cartella `.github/workflows/` (GitHub deve vedere il file `.github/workflows/android-apk.yml` nella radice del repository).
3. Apri la scheda **Actions**, scegli **Build ECLIPSE Android APK** e premi **Run workflow**. Può partire anche dopo un push su `main` o `master`.
4. Se la build riesce, apri l'esecuzione completata e scarica l'artifact **ECLIPSE-Android-debug-APK**.
5. Estrai l'artifact e installa `ECLIPSE-debug.apk` sul telefono. Android potrebbe chiedere di consentire l'installazione da quella fonte.

## Limiti importanti
- Questo produce una build debug per test privato, non una release Play Store.
- Il workflow è predisposto ma non è stato eseguito da questo ambiente: la prima esecuzione cloud deve confermare la disponibilità del container/template e che il progetto superi l'import Godot e l'export.
- Non caricare keystore, password o dati personali nel repository. Per il solo test locale non serve una chiave di release personale.
