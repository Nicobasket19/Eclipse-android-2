extends Node3D

# ECLIPSE 0.4 - prototipo single-player per Godot 4.3, con controlli touch.
const WORLD_RADIUS := 34.0
const SAVE_PATH := "user://eclipse_save.json"
var player: CharacterBody3D
var camera: Camera3D
var enemies: Array[CharacterBody3D] = []
var boss: CharacterBody3D
var props: Node3D
var ui_layer: CanvasLayer
var stats_label: Label
var message_label: Label
var hp_bar: ProgressBar
var xp_bar: ProgressBar
var inventory_panel: PanelContainer
var inventory_label: Label
var joystick_base: Control
var joystick_knob: Control
var touch_vector := Vector2.ZERO
var joystick_touch := -1
var action_attack := false
var action_skill := false
var action_potion := false
var action_inventory := false
var last_attack := 0.0
var last_skill := 0.0
var enemy_spawn_clock := 0.0
var message_clock := 0.0
var hp := 120
var max_hp := 120
var mana := 60
var max_mana := 60
var potions := 5
var gold := 0
var level := 1
var xp := 0
var kills := 0
var quest_kills := 0
var quest_stage := 0
var mission_done := false
var inventory_open := false
var sword_level := 1
var armor_level := 1
var game_time := 0.0
var dead_timer := 0.0

func _ready() -> void:
	_randomize()
	_build_world()
	_build_player()
	_build_ui()
	_spawn_initial_enemies()
	_update_ui()
	_show_message("Benvenuto nelle Terre Perdute. Sconfiggi 6 Ombre per richiamare il Custode.")

func _randomize() -> void:
	randomize()

func _mat(color: Color, roughness := 0.85, metallic := 0.0, emission := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = roughness
	m.metallic = metallic
	if emission > 0.0:
		m.emission_enabled = true
		m.emission = color * emission
	return m

func _mesh_node(parent: Node, mesh: Mesh, color: Color, pos: Vector3, scale_value := Vector3.ONE, emission := 0.0) -> MeshInstance3D:
	var n := MeshInstance3D.new()
	n.mesh = mesh
	n.position = pos
	n.scale = scale_value
	n.material_override = _mat(color, 0.75, 0.05, emission)
	parent.add_child(n)
	return n

func _build_world() -> void:
	var env_node := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.025, 0.045, 0.12)
	sky_mat.sky_horizon_color = Color(0.18, 0.13, 0.24)
	sky_mat.ground_bottom_color = Color(0.035, 0.04, 0.07)
	sky_mat.ground_horizon_color = Color(0.16, 0.12, 0.19)
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.52, 0.55, 0.8)
	env.ambient_light_energy = 0.65
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env_node.environment = env
	add_child(env_node)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -28, 0)
	sun.light_color = Color(0.72, 0.76, 1.0)
	sun.light_energy = 1.25
	add_child(sun)
	var ground := StaticBody3D.new()
	ground.name = "Terra"
	var floor_mesh := PlaneMesh.new()
	floor_mesh.size = Vector2(WORLD_RADIUS * 2.0, WORLD_RADIUS * 2.0)
	_mesh_node(ground, floor_mesh, Color(0.10, 0.13, 0.16), Vector3.ZERO)
	var ground_col := CollisionShape3D.new()
	var ground_shape := BoxShape3D.new()
	ground_shape.size = Vector3(WORLD_RADIUS * 2.0, 0.5, WORLD_RADIUS * 2.0)
	ground_col.shape = ground_shape
	ground_col.position.y = -0.28
	ground.add_child(ground_col)
	add_child(ground)
	props = Node3D.new()
	props.name = "Scenario"
	add_child(props)
	_build_path_and_ruins()
	for i in range(38):
		var p := Vector3(randf_range(-WORLD_RADIUS + 3, WORLD_RADIUS - 3), 0, randf_range(-WORLD_RADIUS + 3, WORLD_RADIUS - 3))
		if Vector2(p.x, p.z).length() > 9.0 and not _near_path(p): _build_dead_tree(p, randf() > 0.5)
	for i in range(24):
		var p := Vector3(randf_range(-WORLD_RADIUS + 2, WORLD_RADIUS - 2), 0, randf_range(-WORLD_RADIUS + 2, WORLD_RADIUS - 2))
		_build_rock(p, randf_range(0.45, 1.2))
	camera = Camera3D.new()
	camera.name = "CameraGioco"
	camera.current = true
	camera.fov = 55
	camera.position = Vector3(0, 10, 13)
	add_child(camera)

func _near_path(p: Vector3) -> bool:
	return abs(p.x) < 3.0 or (abs(p.z + 7.0) < 2.0 and abs(p.x) < 15.0)

func _build_path_and_ruins() -> void:
	var path_mesh := PlaneMesh.new()
	path_mesh.size = Vector2(5.0, 58.0)
	_mesh_node(props, path_mesh, Color(0.19, 0.17, 0.19), Vector3(0, 0.012, 0))
	var cross := PlaneMesh.new()
	cross.size = Vector2(28.0, 3.4)
	_mesh_node(props, cross, Color(0.18, 0.15, 0.18), Vector3(0, 0.014, -8))
	# Portale antico: pietre, pilastri e runa luminosa.
	for side in [-1.0, 1.0]:
		var pillar := BoxMesh.new()
		pillar.size = Vector3(1.2, 4.6, 1.0)
		_mesh_node(props, pillar, Color(0.24, 0.26, 0.34), Vector3(side * 4.3, 2.3, -17))
		var cap := BoxMesh.new()
		cap.size = Vector3(1.55, 0.35, 1.25)
		_mesh_node(props, cap, Color(0.36, 0.33, 0.43), Vector3(side * 4.3, 4.65, -17))
	var lintel := BoxMesh.new()
	lintel.size = Vector3(9.3, 0.75, 1.1)
	_mesh_node(props, lintel, Color(0.29, 0.28, 0.38), Vector3(0, 4.55, -17))
	var rune := TorusMesh.new()
	rune.inner_radius = 1.0
	rune.outer_radius = 1.14
	var ring := _mesh_node(props, rune, Color(0.18, 0.8, 1.0), Vector3(0, 2.5, -17), Vector3(1.3, 1.3, 1.3), 2.2)
	ring.rotation_degrees.x = 90
	# Pietre di confine e bracieri.
	for side in [-1.0, 1.0]:
		for i in range(5):
			var stone := BoxMesh.new()
			stone.size = Vector3(0.75, randf_range(0.5, 1.2), 0.7)
			_mesh_node(props, stone, Color(0.25, 0.24, 0.29), Vector3(side * 7.5, stone.size.y * 0.5, -13 + i * 5))
		var brazier := CylinderMesh.new()
		brazier.top_radius = 0.4
		brazier.bottom_radius = 0.55
		brazier.height = 0.9
		_mesh_node(props, brazier, Color(0.27, 0.28, 0.34), Vector3(side * 3.4, 0.45, 2))
		var flame := SphereMesh.new()
		flame.radius = 0.3
		flame.height = 0.7
		_mesh_node(props, flame, Color(0.12, 0.7, 1.0), Vector3(side * 3.4, 1.15, 2), Vector3(0.8, 1.2, 0.8), 2.0)

func _build_dead_tree(p: Vector3, tall: bool) -> void:
	var tree := Node3D.new()
	tree.position = p
	props.add_child(tree)
	var trunk := CylinderMesh.new()
	trunk.top_radius = 0.16
	trunk.bottom_radius = 0.34
	trunk.height = 2.5 if tall else 1.7
	_mesh_node(tree, trunk, Color(0.17, 0.13, 0.14), Vector3(0, trunk.height * 0.5, 0))
	for i in range(3):
		var branch := CylinderMesh.new()
		branch.top_radius = 0.06
		branch.bottom_radius = 0.12
		branch.height = 1.2
		var b := _mesh_node(tree, branch, Color(0.19, 0.14, 0.17), Vector3(randf_range(-0.55, 0.55), trunk.height * 0.68, randf_range(-0.25, 0.25)))
		b.rotation_degrees = Vector3(0, 0, randf_range(-55, 55))

func _build_rock(p: Vector3, s: float) -> void:
	var rock := SphereMesh.new()
	rock.radius = 0.65
	rock.height = 1.0
	var n := _mesh_node(props, rock, Color(0.22, 0.23, 0.28), p + Vector3(0, 0.25 * s, 0), Vector3(s, s * 0.65, s))
	n.rotation_degrees = Vector3(randf_range(-20, 20), randf_range(0, 360), randf_range(-20, 20))

func _build_player() -> void:
	player = CharacterBody3D.new()
	player.name = "Viandante"
	player.position = Vector3(0, 0.95, 5)
	player.set_meta("is_player", true)
	var model := Node3D.new()
	model.name = "ModelloCavaliere"
	player.add_child(model)
	var body := CapsuleMesh.new()
	body.radius = 0.39
	body.height = 1.25
	_mesh_node(model, body, Color(0.12, 0.32, 0.55), Vector3(0, 0.78, 0))
	var head := SphereMesh.new()
	head.radius = 0.27
	head.height = 0.54
	_mesh_node(model, head, Color(0.78, 0.61, 0.47), Vector3(0, 1.55, 0))
	var helmet := SphereMesh.new()
	helmet.radius = 0.3
	helmet.height = 0.38
	_mesh_node(model, helmet, Color(0.42, 0.48, 0.6), Vector3(0, 1.72, 0), Vector3(1, 0.72, 1))
	var cape := BoxMesh.new()
	cape.size = Vector3(0.65, 0.85, 0.12)
	_mesh_node(model, cape, Color(0.38, 0.07, 0.14), Vector3(0, 0.86, 0.28))
	# Spada con guardia dorata nella mano destra.
	var blade := BoxMesh.new()
	blade.size = Vector3(0.1, 0.95, 0.07)
	var sword := _mesh_node(model, blade, Color(0.7, 0.84, 0.95), Vector3(0.53, 0.82, -0.02), Vector3.ONE, 0.12)
	sword.rotation_degrees.z = -18
	var guard := BoxMesh.new()
	guard.size = Vector3(0.35, 0.08, 0.1)
	_mesh_node(model, guard, Color(0.88, 0.62, 0.22), Vector3(0.53, 0.42, -0.02))
	for side in [-1.0, 1.0]:
		var arm := CapsuleMesh.new()
		arm.radius = 0.12
		arm.height = 0.65
		var a := _mesh_node(model, arm, Color(0.18, 0.35, 0.56), Vector3(side * 0.43, 0.85, 0))
		a.rotation_degrees.z = side * -12
		var boot := BoxMesh.new()
		boot.size = Vector3(0.25, 0.38, 0.32)
		_mesh_node(model, boot, Color(0.12, 0.1, 0.14), Vector3(side * 0.2, 0.18, 0))
	var col := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.4
	shape.height = 1.9
	col.shape = shape
	player.add_child(col)
	add_child(player)

func _spawn_initial_enemies() -> void:
	for i in range(7):
		_spawn_enemy(Vector3(randf_range(-15, 15), 0.7, randf_range(-12, -2)), false)
	for i in range(3):
		_spawn_enemy(Vector3(randf_range(-22, 22), 0.7, randf_range(-25, -19)), false)

func _spawn_enemy(pos: Vector3, is_boss: bool) -> void:
	var enemy := CharacterBody3D.new()
	enemy.name = "Custode" if is_boss else "Ombra"
	enemy.position = pos
	enemy.set_meta("hp", 420 if is_boss else 75)
	enemy.set_meta("max_hp", 420 if is_boss else 75)
	enemy.set_meta("boss", is_boss)
	enemy.set_meta("attack_timer", randf_range(0.3, 1.2))
	enemy.set_meta("hit_flash", 0.0)
	var model := Node3D.new()
	model.name = "Modello"
	enemy.add_child(model)
	if is_boss:
		var torso := CapsuleMesh.new()
		torso.radius = 0.75
		torso.height = 2.3
		_mesh_node(model, torso, Color(0.32, 0.08, 0.2), Vector3(0, 1.2, 0), Vector3(1, 1, 0.8), 0.25)
		var head := SphereMesh.new()
		head.radius = 0.55
		head.height = 1.0
		_mesh_node(model, head, Color(0.56, 0.1, 0.22), Vector3(0, 2.55, 0), Vector3(1, 1.1, 0.9), 0.4)
		for side in [-1.0, 1.0]:
			var horn := ConeMesh.new()
			horn.height = 0.9
			horn.bottom_radius = 0.2
			var h := _mesh_node(model, horn, Color(0.9, 0.28, 0.22), Vector3(side * 0.45, 3.1, 0), Vector3.ONE, 0.5)
			h.rotation_degrees.z = side * 25
		var eye := SphereMesh.new()
		eye.radius = 0.12
		eye.height = 0.24
		for side in [-1.0, 1.0]: _mesh_node(model, eye, Color(1.0, 0.55, 0.08), Vector3(side * 0.23, 2.62, -0.43), Vector3.ONE, 2.0)
	else:
		var body := CapsuleMesh.new()
		body.radius = 0.4
		body.height = 1.45
		_mesh_node(model, body, Color(0.2, 0.16, 0.35), Vector3(0, 0.82, 0), Vector3(1, 1, 0.85), 0.3)
		var head := SphereMesh.new()
		head.radius = 0.32
		head.height = 0.62
		_mesh_node(model, head, Color(0.28, 0.2, 0.42), Vector3(0, 1.7, 0), Vector3(1, 1.1, 0.85), 0.35)
		var eye := SphereMesh.new()
		eye.radius = 0.075
		eye.height = 0.15
		for side in [-1.0, 1.0]: _mesh_node(model, eye, Color(0.35, 0.9, 1.0), Vector3(side * 0.13, 1.72, -0.27), Vector3.ONE, 1.7)
		for side in [-1.0, 1.0]:
			var claw := ConeMesh.new()
			claw.height = 0.38
			claw.bottom_radius = 0.11
			var c := _mesh_node(model, claw, Color(0.52, 0.45, 0.7), Vector3(side * 0.43, 0.55, -0.1))
			c.rotation_degrees.z = 180
	var col := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.8 if is_boss else 0.48
	shape.height = 2.4 if is_boss else 1.6
	col.shape = shape
	col.position.y = 0.95 if is_boss else 0.75
	enemy.add_child(col)
	add_child(enemy)
	if is_boss:
		boss = enemy
		_show_message("IL CUSTODE SI È RISVEGLIATO! Schiva e colpisci quando si avvicina.")
	else:
		enemies.append(enemy)

func _build_ui() -> void:
	ui_layer = CanvasLayer.new()
	add_child(ui_layer)
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_PASS
	ui_layer.add_child(root)
	var top := PanelContainer.new()
	top.position = Vector2(18, 16)
	top.custom_minimum_size = Vector2(315, 142)
	root.add_child(top)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 4)
	top.add_child(v)
	var title := Label.new()
	title.text = "E C L I P S E   //   TERRE PERDUTE"
	title.add_theme_font_size_override("font_size", 17)
	v.add_child(title)
	stats_label = Label.new()
	stats_label.add_theme_font_size_override("font_size", 14)
	v.add_child(stats_label)
	hp_bar = ProgressBar.new()
	hp_bar.custom_minimum_size.y = 15
	hp_bar.show_percentage = false
	v.add_child(hp_bar)
	xp_bar = ProgressBar.new()
	xp_bar.custom_minimum_size.y = 10
	xp_bar.show_percentage = false
	v.add_child(xp_bar)
	message_label = Label.new()
	message_label.position = Vector2(18, 174)
	message_label.custom_minimum_size = Vector2(570, 45)
	message_label.add_theme_font_size_override("font_size", 17)
	message_label.add_theme_color_override("font_color", Color(0.65, 0.9, 1.0))
	root.add_child(message_label)
	# Joystick touch, nella parte bassa sinistra.
	joystick_base = Control.new()
	joystick_base.position = Vector2(38, 0)
	joystick_base.anchor_top = 1.0
	joystick_base.anchor_bottom = 1.0
	joystick_base.offset_top = -190
	joystick_base.offset_bottom = -30
	joystick_base.custom_minimum_size = Vector2(160, 160)
	joystick_base.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(joystick_base)
	var base_circle := ColorRect.new()
	base_circle.color = Color(0.2, 0.35, 0.55, 0.28)
	base_circle.size = Vector2(150, 150)
	base_circle.position = Vector2(0, 5)
	base_circle.mouse_filter = Control.MOUSE_FILTER_IGNORE
	joystick_base.add_child(base_circle)
	joystick_knob = ColorRect.new()
	joystick_knob.color = Color(0.55, 0.8, 1.0, 0.72)
	joystick_knob.size = Vector2(58, 58)
	joystick_knob.position = Vector2(46, 51)
	joystick_knob.mouse_filter = Control.MOUSE_FILTER_IGNORE
	joystick_base.add_child(joystick_knob)
	# Pulsanti touch a destra.
	_add_touch_button(root, "ATTACCO", Vector2(-176, -112), Vector2(142, 76), "attack")
	_add_touch_button(root, "ABILITÀ", Vector2(-310, -100), Vector2(112, 64), "skill")
	_add_touch_button(root, "POZIONE", Vector2(-176, -202), Vector2(112, 64), "potion")
	_add_touch_button(root, "ZAINO", Vector2(-310, -184), Vector2(112, 64), "inventory")
	# Pulsanti touch ancorati al bordo destro; Salva/Carica restano in basso a sinistra.
	inventory_panel = PanelContainer.new()
	inventory_panel.anchor_left = 0.5
	inventory_panel.anchor_right = 0.5
	inventory_panel.anchor_top = 0.5
	inventory_panel.anchor_bottom = 0.5
	inventory_panel.offset_left = -170
	inventory_panel.offset_right = 170
	inventory_panel.offset_top = -140
	inventory_panel.offset_bottom = 140
	inventory_panel.visible = false
	root.add_child(inventory_panel)
	inventory_label = Label.new()
	inventory_label.add_theme_font_size_override("font_size", 18)
	inventory_panel.add_child(inventory_label)
	var save_button := Button.new()
	save_button.text = "SALVA"
	save_button.position = Vector2(18, 0)
	save_button.anchor_top = 1.0
	save_button.anchor_bottom = 1.0
	save_button.offset_top = -45
	save_button.offset_bottom = -10
	save_button.custom_minimum_size = Vector2(90, 35)
	save_button.pressed.connect(_save_game)
	root.add_child(save_button)
	var load_button := Button.new()
	load_button.text = "CARICA"
	load_button.position = Vector2(116, 0)
	load_button.anchor_top = 1.0
	load_button.anchor_bottom = 1.0
	load_button.offset_top = -45
	load_button.offset_bottom = -10
	load_button.custom_minimum_size = Vector2(90, 35)
	load_button.pressed.connect(_load_game)
	root.add_child(load_button)

func _add_touch_button(root: Control, caption: String, offsets: Vector2, size_value: Vector2, action: String) -> void:
	var b := Button.new()
	b.text = caption
	b.custom_minimum_size = size_value
	b.anchor_left = 1.0
	b.anchor_right = 1.0
	b.anchor_top = 1.0
	b.anchor_bottom = 1.0
	b.offset_left = offsets.x
	b.offset_right = offsets.x + size_value.x
	b.offset_top = offsets.y
	b.offset_bottom = offsets.y + size_value.y
	b.add_theme_font_size_override("font_size", 16)
	b.modulate = Color(0.78, 0.9, 1.0, 0.92)
	b.pressed.connect(func(): _on_ui_action(action))
	root.add_child(b)

func _on_ui_action(action: String) -> void:
	match action:
		"attack": _attack(false)
		"skill": _attack(true)
		"potion": _use_potion()
		"inventory":
			inventory_open = not inventory_open
			inventory_panel.visible = inventory_open
			_update_ui()

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and event.position.x < get_viewport().get_visible_rect().size.x * 0.48 and event.position.y > get_viewport().get_visible_rect().size.y * 0.55:
			joystick_touch = event.index
			_update_joystick(event.position)
		elif not event.pressed and event.index == joystick_touch:
			joystick_touch = -1
			touch_vector = Vector2.ZERO
			_set_joystick_knob(Vector2.ZERO)
	elif event is InputEventScreenDrag and event.index == joystick_touch:
		_update_joystick(event.position)
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_H: _use_potion()
			KEY_Q: _attack(true)
			KEY_I:
				inventory_open = not inventory_open
				inventory_panel.visible = inventory_open
				_update_ui()
			KEY_F5: _save_game()
			KEY_F9: _load_game()
			KEY_ESCAPE:
				inventory_open = false
				inventory_panel.visible = false

func _update_joystick(screen_pos: Vector2) -> void:
	var local := screen_pos - (joystick_base.global_position + Vector2(75, 80))
	touch_vector = local.limit_length(58.0) / 58.0
	_set_joystick_knob(touch_vector * 45.0)

func _set_joystick_knob(offset: Vector2) -> void:
	if is_instance_valid(joystick_knob): joystick_knob.position = Vector2(46, 51) + offset

func _physics_process(delta: float) -> void:
	if not is_instance_valid(player): return
	game_time += delta
	last_attack = maxf(0.0, last_attack - delta)
	last_skill = maxf(0.0, last_skill - delta)
	message_clock = maxf(0.0, message_clock - delta)
	if message_clock <= 0.0 and is_instance_valid(message_label): message_label.text = ""
	var dir := Vector3.ZERO
	dir.x = Input.get_action_strength("move_right") - Input.get_action_strength("move_left")
	dir.z = Input.get_action_strength("move_back") - Input.get_action_strength("move_forward")
	dir.x += touch_vector.x
	dir.z += touch_vector.y
	if dir.length() > 1.0: dir = dir.normalized()
	player.velocity.x = dir.x * (7.0 + level * 0.08)
	player.velocity.z = dir.z * (7.0 + level * 0.08)
	player.move_and_slide()
	player.position.x = clampf(player.position.x, -WORLD_RADIUS + 1, WORLD_RADIUS - 1)
	player.position.z = clampf(player.position.z, -WORLD_RADIUS + 1, WORLD_RADIUS - 1)
	if dir.length() > 0.1:
		var model := player.get_node_or_null("ModelloCavaliere")
		if model: model.rotation.y = lerp_angle(model.rotation.y, atan2(dir.x, dir.z) + PI, delta * 9.0)
	camera.global_position = camera.global_position.lerp(player.global_position + Vector3(0, 10.5, 12.5), delta * 4.0)
	camera.look_at(player.global_position + Vector3(0, 0.6, 0), Vector3.UP)
	for enemy in enemies.duplicate():
		if not is_instance_valid(enemy):
			enemies.erase(enemy)
			continue
		_enemy_update(enemy, delta)
	if is_instance_valid(boss): _enemy_update(boss, delta)
	if Input.is_action_just_pressed("attack") and last_attack <= 0.0: _attack(false)
	if hp <= 0:
		dead_timer += delta
		if dead_timer > 2.0:
			hp = max_hp
			mana = max_mana
			player.global_position = Vector3(0, 0.95, 5)
			dead_timer = 0.0
			_show_message("Sei stato sconfitto e riportato al santuario. Le Ombre ti aspettano.")
			_update_ui()

func _enemy_update(enemy: CharacterBody3D, delta: float) -> void:
	if not is_instance_valid(enemy): return
	var to_player := player.global_position - enemy.global_position
	to_player.y = 0
	var distance := to_player.length()
	var is_boss := bool(enemy.get_meta("boss", false))
	var speed := 2.0 if is_boss else 1.5
	if distance > (2.5 if is_boss else 1.65):
		if distance < (24.0 if is_boss else 18.0):
			enemy.velocity.x = to_player.normalized().x * speed
			enemy.velocity.z = to_player.normalized().z * speed
			var mdl := enemy.get_node_or_null("Modello")
			if mdl: mdl.rotation.y = atan2(to_player.x, to_player.z) + PI
		else:
			enemy.velocity.x = 0
			enemy.velocity.z = 0
	else:
		enemy.velocity.x = 0
		enemy.velocity.z = 0
		var timer := float(enemy.get_meta("attack_timer", 1.0)) - delta
		if timer <= 0.0:
			timer = 1.1 if is_boss else 1.35
			hp -= 13 if is_boss else 6
			if hp < 0: hp = 0
			_update_ui()
		enemy.set_meta("attack_timer", timer)
	enemy.move_and_slide()

func _attack(aoe: bool) -> void:
	if not is_instance_valid(player): return
	if aoe:
		if last_skill > 0.0: _show_message("Abilità in ricarica: %.1f s" % last_skill); return
		if mana < 18: _show_message("Mana insufficiente."); return
		mana -= 18
		last_skill = 5.0
	else:
		if last_attack > 0.0: return
		last_attack = 0.48
	var range_value := 5.0 if aoe else 2.6
	var damage := 58 + (sword_level - 1) * 12 + level * 2 if aoe else 28 + (sword_level - 1) * 8 + level * 2
	var hit := false
	for enemy in enemies.duplicate():
		if is_instance_valid(enemy) and player.global_position.distance_to(enemy.global_position) <= range_value:
			_damage_enemy(enemy, damage)
			hit = true
	if is_instance_valid(boss) and player.global_position.distance_to(boss.global_position) <= range_value + 0.6:
		_damage_enemy(boss, damage)
		hit = true
	if aoe:
		_show_message("Onda d'Eclisse!" if hit else "L'onda non ha raggiunto nessun nemico.")
	elif not hit:
		_show_message("Avvicinati a un'Ombra per colpirla.")
	_update_ui()

func _damage_enemy(enemy: CharacterBody3D, damage: int) -> void:
	var remaining := int(enemy.get_meta("hp", 1)) - damage
	enemy.set_meta("hp", remaining)
	var mdl := enemy.get_node_or_null("Modello")
	if mdl:
		mdl.scale = Vector3(1.12, 1.12, 1.12)
		var tween := create_tween()
		tween.tween_property(mdl, "scale", Vector3.ONE, 0.12)
	if remaining <= 0:
		if bool(enemy.get_meta("boss", false)):
			boss = null
			enemy.queue_free()
			gold += 180
			xp += 250
			mission_done = true
			quest_stage = 2
			_show_message("CUSTODE SCONFITTO! La reliquia è tua. Hai completato il capitolo I.")
		else:
			enemies.erase(enemy)
			enemy.queue_free()
			kills += 1
			quest_kills += 1
			gold += randi_range(5, 14)
			xp += 32
			if randf() < 0.16: potions += 1; _show_message("Un'Ombra ha lasciato una pozione!")
			if quest_kills >= 6 and not mission_done and not is_instance_valid(boss):
				quest_stage = 1
				_spawn_enemy(Vector3(0, 0.7, -17), true)
			if enemies.size() < 5 and not mission_done:
				_spawn_enemy(Vector3(randf_range(-20, 20), 0.7, randf_range(-22, 0)), false)
			if xp >= level * 100:
				xp -= level * 100
				level += 1
				max_hp += 12
				hp = max_hp
				max_mana += 5
				mana = max_mana
				_show_message("LIVELLO %d! Vita e mana ripristinati." % level)
	_update_ui()

func _use_potion() -> void:
	if potions <= 0: _show_message("Non hai pozioni."); return
	if hp >= max_hp and mana >= max_mana: _show_message("Sei già in piena forma."); return
	potions -= 1
	hp = mini(max_hp, hp + 55)
	mana = mini(max_mana, mana + 20)
	_show_message("Pozione utilizzata: vita e mana ripristinati.")
	_update_ui()

func _update_ui() -> void:
	if not is_instance_valid(stats_label): return
	var quest_text := "Sconfiggi Ombre: %d/6" % mini(quest_kills, 6) if quest_stage == 0 else ("Custode della Soglia" if not mission_done else "Capitolo I completato")
	stats_label.text = "Livello %d   EXP %d/%d\nOro %d   Pozioni %d   Spada +%d\n%s" % [level, xp, level * 100, gold, potions, sword_level, quest_text]
	hp_bar.max_value = max_hp
	hp_bar.value = hp
	hp_bar.modulate = Color(0.45, 0.95, 0.65) if hp > max_hp * 0.35 else Color(1.0, 0.3, 0.28)
	xp_bar.max_value = level * 100
	xp_bar.value = xp
	if is_instance_valid(inventory_label):
		inventory_label.text = "INVENTARIO DEL VIANDANTE\n\nLivello: %d\nVita: %d/%d\nMana: %d/%d\nOro: %d\nPozioni: %d\nSpada: +%d\nArmatura: +%d\n\nPremi ZAINO per chiudere." % [level, hp, max_hp, mana, max_mana, gold, potions, sword_level, armor_level]

func _show_message(text_value: String) -> void:
	if is_instance_valid(message_label):
		message_label.text = text_value
		message_clock = 4.5

func _save_game() -> void:
	if not is_instance_valid(player): return
	var data := {"hp": hp, "max_hp": max_hp, "mana": mana, "max_mana": max_mana, "potions": potions, "gold": gold, "level": level, "xp": xp, "kills": kills, "quest_kills": quest_kills, "quest_stage": quest_stage, "mission_done": mission_done, "sword_level": sword_level, "armor_level": armor_level, "player_pos": [player.position.x, player.position.y, player.position.z]}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(data))
		_show_message("Progressi salvati sul dispositivo.")

func _load_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH): _show_message("Non esiste ancora un salvataggio."); return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	var parsed = JSON.parse_string(f.get_as_text())
	if typeof(parsed) != TYPE_DICTIONARY: _show_message("Salvataggio non valido."); return
	var d: Dictionary = parsed
	hp = int(d.get("hp", 120)); max_hp = int(d.get("max_hp", 120))
	mana = int(d.get("mana", 60)); max_mana = int(d.get("max_mana", 60))
	potions = int(d.get("potions", 5)); gold = int(d.get("gold", 0)); level = int(d.get("level", 1)); xp = int(d.get("xp", 0))
	kills = int(d.get("kills", 0)); quest_kills = int(d.get("quest_kills", 0)); quest_stage = int(d.get("quest_stage", 0)); mission_done = bool(d.get("mission_done", false))
	sword_level = int(d.get("sword_level", 1)); armor_level = int(d.get("armor_level", 1))
	var p: Array = d.get("player_pos", [0, 0.95, 5])
	player.position = Vector3(float(p[0]), float(p[1]), float(p[2]))
	# Ripristina lo stato del boss in base alla fase della missione salvata.
	if is_instance_valid(boss):
		boss.queue_free()
		boss = null
	if quest_stage == 1 and not mission_done:
		_spawn_enemy(Vector3(0, 0.7, -17), true)
	_update_ui()
	_show_message("Salvataggio caricato.")
