# ECLIPSE — Le Terre Perdute (build corretta 0.4.1)

Progetto sorgente Godot 4.3, single-player 3D, con geometrie procedurali e renderer Compatibility orientato ai dispositivi mobili.

## Importazione
1. Estrai l'archivio in una cartella.
2. Apri Godot 4.3, scegli **Importa** e seleziona `project.godot`.
3. Premi F6 per avviare la scena principale oppure F5 per avviare il progetto.

## Comandi
- PC: WASD/frecce per muoversi, Spazio/clic sinistro per attaccare, Q abilità, H pozione, I inventario, F5 salva, F9 carica.
- Android: joystick virtuale in basso a sinistra; pulsanti ATTACCO, ABILITÀ, POZIONE e ZAINO a destra; SALVA/CARICA in basso a sinistra.

## Contenuti presenti nel prototipo
- Scenario 3D procedurale con terreno, sentiero, portale, rovine, alberi secchi, rocce e bracieri.
- Eroe, Ombre e Custode realizzati con mesh 3D create via codice.
- IA semplice, combattimento, cooldown, mana, pozioni, esperienza, livelli, oro e missione del Capitolo I.
- Salvataggio locale in `user://eclipse_save.json`; il caricamento ripristina anche la fase della missione e il boss quando necessario.

## Verifiche eseguite in questo ambiente
- Controllo statico: 27/27 verifiche superate (configurazione, riferimenti risorsa, metodi essenziali e delimitatori).
- Archivio ZIP: verificato dopo la creazione.
- **Non è stato possibile avviare il motore Godot in questo ambiente**, perché l'eseguibile Godot, i template Android e l'SDK Android non sono installati e la rete dell'ambiente non consente di scaricarli. Di conseguenza, il controllo statico non sostituisce il parsing e il test runtime in Godot.

## APK Android
Questo è il progetto sorgente, non un APK. Per creare un APK valido servono il motore Godot della versione scelta, i template di esportazione corrispondenti e JDK/Android SDK configurati. Non dichiarare l'APK pronto finché non è stato esportato e installato su un dispositivo reale.

## Stato del progetto
È un prototipo giocabile da verificare, non ancora un gioco commerciale completo: non contiene multiplayer, asset artistici esterni, animazioni scheletriche, una campagna estesa o un sistema completo di equipaggiamento.
