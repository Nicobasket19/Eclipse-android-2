#!/usr/bin/env python3
"""Static sanity checks for ECLIPSE. This is not a substitute for Godot's parser/runtime."""
from pathlib import Path
import re, sys
ROOT = Path(__file__).resolve().parents[1]
errors, checks = [], []
def check(ok, label):
    checks.append((bool(ok), label))
    if not ok: errors.append(label)

project = (ROOT / 'project.godot').read_text()
scene = (ROOT / 'scenes/EclipseWorld.tscn').read_text()
script = (ROOT / 'scripts/world.gd').read_text()
check('config_version=5' in project, 'project.godot config_version')
check('run/main_scene="res://scenes/EclipseWorld.tscn"' in project, 'main scene configured')
check('res://scripts/world.gd' in scene, 'main scene references world.gd')
check('renderer/rendering_method.mobile="gl_compatibility"' in project, 'mobile Compatibility renderer')
check('move_right={' in project and re.search(r'^move_right=.*\]\}\s*$', project, re.M), 'move_right InputMap line is closed')
for action in ('move_forward','move_back','move_left','move_right','attack'):
    check(re.search(r'^'+action+r'=\{', project, re.M) is not None, f'InputMap action: {action}')
# Verify all res:// paths referenced by the project exist.
for path in re.findall(r'res://[^"\s)]+', project + scene + script):
    if '://' in path and path.startswith('res://'):
        check((ROOT / path[6:]).exists(), f'resource exists: {path}')
# Methods used as direct callbacks must be defined.
for method in ('_ready','_physics_process','_input','_build_world','_build_player','_build_ui','_spawn_initial_enemies','_update_ui','_save_game','_load_game','_attack','_use_potion'):
    check(re.search(r'^func\s+'+re.escape(method)+r'\s*\(', script, re.M) is not None, f'method exists: {method}')
# Basic delimiter scan, ignoring quoted strings and comments; catches common editing mistakes.
def delimiter_errors(src):
    stack=[]; pairs={')':'(',']':'[','}':'{'}; quote=None; escaped=False
    for ln,line in enumerate(src.splitlines(),1):
        i=0
        while i < len(line):
            c=line[i]
            if quote:
                if escaped: escaped=False
                elif c=='\\': escaped=True
                elif c==quote: quote=None
                i+=1; continue
            if c=='#': break
            if c in ('"', "'"): quote=c
            elif c in '([{': stack.append((c,ln))
            elif c in ')]}':
                if not stack or stack[-1][0] != pairs[c]: return f'unmatched {c} at line {ln}'
                stack.pop()
            i+=1
    if quote: return 'unterminated string literal'
    if stack: return f'unclosed {stack[-1][0]} from line {stack[-1][1]}'
    return None
for label, src in (('project.godot', project), ('world.gd', script), ('EclipseWorld.tscn', scene)):
    err=delimiter_errors(src)
    check(err is None, f'delimiter balance: {label}' + (f' ({err})' if err else ''))

for ok,label in checks: print(('PASS' if ok else 'FAIL')+'  '+label)
print(f'\n{sum(ok for ok,_ in checks)}/{len(checks)} static checks passed.')
print('IMPORTANT: static checks do not compile or run GDScript. Run this project with Godot to complete runtime verification.')
sys.exit(1 if errors else 0)
